--
-- PostgreSQL database dump
--

\restrict jJ4hNkwNRVuddMdGFAMa8ZOlq4NFI5QAi2Vqh82apHW6uG5CShvpitClzdco09D

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AppointmentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AppointmentStatus" AS ENUM (
    'PENDIENTE',
    'CONFIRMADO',
    'FINALIZADO',
    'CANCELADO'
);


--
-- Name: AttachmentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AttachmentType" AS ENUM (
    'FOTO',
    'VIDEO'
);


--
-- Name: EquipmentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EquipmentType" AS ENUM (
    'AIRE_ACONDICIONADO',
    'HELADERA',
    'FREEZER',
    'OTRO'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'EFECTIVO',
    'TRANSFERENCIA',
    'MERCADO_PAGO',
    'TARJETA',
    'OTRO'
);


--
-- Name: VisitReason; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VisitReason" AS ENUM (
    'LIMPIEZA',
    'MANTENIMIENTO',
    'REPARACION',
    'OTRO'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Appointment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Appointment" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "equipmentId" text,
    "createdById" text,
    date timestamp(3) without time zone NOT NULL,
    "time" text NOT NULL,
    status public."AppointmentStatus" DEFAULT 'PENDIENTE'::public."AppointmentStatus" NOT NULL,
    "equipmentType" public."EquipmentType" NOT NULL,
    "visitReason" public."VisitReason" NOT NULL,
    "problemDescription" text NOT NULL,
    address text NOT NULL,
    neighborhood text,
    city text DEFAULT 'Posadas'::text NOT NULL,
    "waitingFeeNotice" boolean DEFAULT true NOT NULL,
    "waitingFeeAmount" integer DEFAULT 30000 NOT NULL,
    "finalPrice" integer,
    "paymentMethod" public."PaymentMethod",
    paid boolean DEFAULT false NOT NULL,
    "technicianNotes" text,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "finalizedAt" timestamp(3) without time zone,
    "cancelledAt" timestamp(3) without time zone
);


--
-- Name: Attachment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Attachment" (
    id text NOT NULL,
    "appointmentId" text NOT NULL,
    type public."AttachmentType" NOT NULL,
    url text NOT NULL,
    "fileName" text,
    "mimeType" text,
    size integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Client" (
    id text NOT NULL,
    "fullName" text NOT NULL,
    phone text NOT NULL,
    address text NOT NULL,
    neighborhood text,
    city text DEFAULT 'Posadas'::text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Equipment" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    type public."EquipmentType" NOT NULL,
    brand text,
    model text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Service" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "visitReason" public."VisitReason" NOT NULL,
    "basePrice" integer,
    "estimatedDurationMinutes" integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role text DEFAULT 'ADMIN'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: Appointment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Appointment" (id, "clientId", "equipmentId", "createdById", date, "time", status, "equipmentType", "visitReason", "problemDescription", address, neighborhood, city, "waitingFeeNotice", "waitingFeeAmount", "finalPrice", "paymentMethod", paid, "technicianNotes", "cancellationReason", "createdAt", "updatedAt", "finalizedAt", "cancelledAt") FROM stdin;
\.


--
-- Data for Name: Attachment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Attachment" (id, "appointmentId", type, url, "fileName", "mimeType", size, "createdAt") FROM stdin;
\.


--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Client" (id, "fullName", phone, address, neighborhood, city, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Equipment" (id, "clientId", type, brand, model, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Service" (id, name, description, "visitReason", "basePrice", "estimatedDurationMinutes", "isActive", "createdAt", "updatedAt") FROM stdin;
ab9103aa-6929-404f-9868-7c2cda7c4cc5	Limpieza de aire acondicionado	Limpieza general del equipo, filtros y revisión básica.	LIMPIEZA	\N	90	t	2026-06-13 17:20:12.059	2026-06-13 17:20:12.059
108a1c2d-7497-4fdd-a00f-adc4fd0b9ed7	Mantenimiento de aire acondicionado	Mantenimiento preventivo del equipo de aire acondicionado.	MANTENIMIENTO	\N	90	t	2026-06-13 17:20:12.059	2026-06-13 17:20:12.059
5a88925d-c81b-4ccd-bee0-50adc6bb94d5	Reparación de aire acondicionado	Diagnóstico y reparación de fallas en equipos de aire acondicionado.	REPARACION	\N	120	t	2026-06-13 17:20:12.059	2026-06-13 17:20:12.059
468a3d85-6f7d-4810-a7d7-93fe2f0b69aa	Reparación de heladera	Diagnóstico y reparación de heladeras.	REPARACION	\N	120	t	2026-06-13 17:20:12.059	2026-06-13 17:20:12.059
9ee129c6-948e-47fe-834f-66881c225c15	Reparación de freezer	Diagnóstico y reparación de freezers.	REPARACION	\N	120	t	2026-06-13 17:20:12.059	2026-06-13 17:20:12.059
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "userId", token, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, "passwordHash", role, "createdAt", "updatedAt") FROM stdin;
9e0d0bcd-9d40-4a27-8a69-d7974cf7c4f6	Administrador	admin@osopolar.com	$2b$12$/b6/8V0qw0JfrOXfhizEwOx6BgPLz.dql5YzGqC9lrzlKcZmzQjWq	ADMIN	2026-06-13 17:20:25.823	2026-06-13 17:20:25.823
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
507ad50b-5187-484c-9840-07ea986639ec	4bd6153fc0c0f771b0b27c8d820f3558ff336dead17616305793bcee5685128e	2026-06-13 17:13:29.79582+00	20260608163600_init	\N	\N	2026-06-13 17:13:29.552142+00	1
47a6a236-9a4a-435d-9c5c-f1bb34bf2155	b2ac44334d99a29b134fa1b79491032564a20744d932ad841121dd2de8ddad1e	2026-06-13 17:13:29.816529+00	20260608165430_add_unique_phone_to_client	\N	\N	2026-06-13 17:13:29.800787+00	1
2073c54e-664c-4784-aef5-ee30ec6ff97f	f378ae849e1c62fa340eb1ca898477106df08bd9f1cc3b791712149264cca47c	2026-06-13 17:13:29.871331+00	20260612152258_add_sessions	\N	\N	2026-06-13 17:13:29.820718+00	1
\.


--
-- Name: Appointment Appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_pkey" PRIMARY KEY (id);


--
-- Name: Attachment Attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: Equipment Equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_pkey" PRIMARY KEY (id);


--
-- Name: Service Service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Appointment_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_clientId_idx" ON public."Appointment" USING btree ("clientId");


--
-- Name: Appointment_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_date_idx" ON public."Appointment" USING btree (date);


--
-- Name: Appointment_equipmentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_equipmentId_idx" ON public."Appointment" USING btree ("equipmentId");


--
-- Name: Appointment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Appointment_status_idx" ON public."Appointment" USING btree (status);


--
-- Name: Attachment_appointmentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Attachment_appointmentId_idx" ON public."Attachment" USING btree ("appointmentId");


--
-- Name: Client_fullName_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Client_fullName_idx" ON public."Client" USING btree ("fullName");


--
-- Name: Client_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Client_phone_idx" ON public."Client" USING btree (phone);


--
-- Name: Client_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Client_phone_key" ON public."Client" USING btree (phone);


--
-- Name: Equipment_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Equipment_clientId_idx" ON public."Equipment" USING btree ("clientId");


--
-- Name: Equipment_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Equipment_type_idx" ON public."Equipment" USING btree (type);


--
-- Name: Service_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Service_isActive_idx" ON public."Service" USING btree ("isActive");


--
-- Name: Service_visitReason_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Service_visitReason_idx" ON public."Service" USING btree ("visitReason");


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_token_idx" ON public."Session" USING btree (token);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Appointment Appointment_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Appointment Appointment_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Appointment Appointment_equipmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_equipmentId_fkey" FOREIGN KEY ("equipmentId") REFERENCES public."Equipment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Attachment Attachment_appointmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_appointmentId_fkey" FOREIGN KEY ("appointmentId") REFERENCES public."Appointment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Equipment Equipment_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict jJ4hNkwNRVuddMdGFAMa8ZOlq4NFI5QAi2Vqh82apHW6uG5CShvpitClzdco09D

